#include <stdlib.h>

#include <stdio.h>
#include <string.h>

#include <raylib.h>

#define RRES_RAYLIB_IMPLEMENTATION
#define RRES_SUPPORT_COMPRESSION_LZ4
#include "rres-raylib.h"