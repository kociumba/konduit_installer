#define RRES_IMPLEMENTATION
#include "rres.h"